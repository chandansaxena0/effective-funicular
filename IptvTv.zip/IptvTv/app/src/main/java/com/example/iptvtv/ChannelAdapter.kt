package com.example.iptvtv

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.dispose
import coil.load

class ChannelAdapter(
    private val onClick: (Channel) -> Unit,
    private val onLongClick: (Channel) -> Unit,
    private val isFavourite: (Channel) -> Boolean,
) : ListAdapter<Channel, ChannelAdapter.VH>(Diff) {

    private var playingUrl: String? = null

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val logo: ImageView = view.findViewById(R.id.logo)
        val name: TextView = view.findViewById(R.id.name)
        val group: TextView = view.findViewById(R.id.group)
        val star: TextView = view.findViewById(R.id.star)
    }

    fun setPlaying(url: String?) {
        val old = playingUrl
        playingUrl = url
        val list = currentList
        for (i in list.indices) {
            val u = list[i].url
            if (u == old || u == url) notifyItemChanged(i)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        val vh = VH(v)
        v.setOnClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(getItem(p))
        }
        v.setOnLongClickListener {
            val p = vh.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(getItem(p))
            true
        }
        return vh
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = getItem(position)
        holder.name.text = c.name
        holder.group.text = c.group
        holder.star.visibility = if (isFavourite(c)) View.VISIBLE else View.GONE
        holder.name.setTextColor(if (c.url == playingUrl) ACCENT else Color.WHITE)

        val logo = c.logo
        if (logo == null) {
            holder.logo.dispose()
            holder.logo.setImageResource(R.drawable.ic_tv)
        } else {
            holder.logo.load(logo) {
                size(96) // tiny bitmaps keep scrolling smooth
                placeholder(R.drawable.ic_tv)
                error(R.drawable.ic_tv)
                crossfade(false)
            }
        }
    }

    private object Diff : DiffUtil.ItemCallback<Channel>() {
        override fun areItemsTheSame(a: Channel, b: Channel) = a.url == b.url && a.name == b.name
        override fun areContentsTheSame(a: Channel, b: Channel) = a == b
    }

    private companion object {
        val ACCENT = Color.parseColor("#4FC3F7")
    }
}
