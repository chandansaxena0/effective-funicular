package com.example.iptvtv

import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private lateinit var repo: ChannelRepository
    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: ChannelAdapter

    private lateinit var playerView: PlayerView
    private lateinit var panel: View
    private lateinit var channelList: RecyclerView
    private lateinit var search: EditText
    private lateinit var groupBtn: Button
    private lateinit var refreshBtn: Button
    private lateinit var status: TextView
    private lateinit var banner: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var errorText: TextView

    private var player: ExoPlayer? = null
    private val httpFactory = DefaultHttpDataSource.Factory()
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(10_000)
        .setReadTimeoutMs(10_000)
        .setUserAgent(DEFAULT_UA)

    private var all: List<Channel> = emptyList()
    private var visible: List<Channel> = emptyList()
    private var groups: List<Pair<String, Int>> = emptyList()
    private var group: String? = null // null = all, FAVOURITES = favourites
    private var query = ""
    private var current: Channel? = null
    private var autoStarted = false
    private var retries = 0
    private var filterJob: Job? = null
    private val favourites = HashSet<String>()

    private val handler = Handler(Looper.getMainLooper())
    private val hideBanner = Runnable { banner.visibility = View.GONE }
    private val retryPlayback = Runnable { player?.prepare() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = ChannelRepository(applicationContext)
        prefs = getSharedPreferences("iptv", MODE_PRIVATE)
        favourites.addAll(prefs.getStringSet(KEY_FAVS, emptySet()) ?: emptySet())

        playerView = findViewById(R.id.player_view)
        panel = findViewById(R.id.panel)
        channelList = findViewById(R.id.channel_list)
        search = findViewById(R.id.search)
        groupBtn = findViewById(R.id.group_btn)
        refreshBtn = findViewById(R.id.refresh_btn)
        status = findViewById(R.id.status)
        banner = findViewById(R.id.banner)
        spinner = findViewById(R.id.spinner)
        errorText = findViewById(R.id.error_text)

        adapter = ChannelAdapter(
            onClick = { c ->
                play(c)
                hidePanel()
            },
            onLongClick = { c -> toggleFavourite(c) },
            isFavourite = { c -> c.url in favourites },
        )
        channelList.layoutManager = LinearLayoutManager(this)
        channelList.adapter = adapter
        channelList.setHasFixedSize(true)
        channelList.itemAnimator = null
        channelList.setItemViewCacheSize(16)

        groupBtn.setOnClickListener { showGroupDialog() }
        refreshBtn.setOnClickListener { refresh(true) }
        search.doAfterTextChanged {
            query = it?.toString().orEmpty()
            applyFilter(scrollTop = true)
        }
        search.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            focusList()
            true
        }

        lifecycleScope.launch {
            val stale = repo.cacheAgeMs() > REFRESH_AFTER_MS
            val cached = withContext(Dispatchers.IO) {
                runCatching { repo.loadCached() }.getOrDefault(emptyList())
            }
            if (cached.isNotEmpty()) setChannels(cached)
            if (cached.isEmpty() || stale) refresh(userInitiated = cached.isEmpty())
            if (cached.isEmpty()) updateStatus("Loading channel list…")
        }
    }

    // ---------------------------------------------------------------- player

    private fun initPlayer() {
        val loadControl = DefaultLoadControl.Builder()
            // Small start-up buffer = fast channel changes; larger max = fewer stalls.
            .setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(httpFactory))
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                spinner.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                if (state == Player.STATE_READY) {
                    errorText.visibility = View.GONE
                    retries = 0
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val pl = player ?: return
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    pl.seekToDefaultPosition()
                    pl.prepare()
                    return
                }
                if (retries < MAX_RETRIES) {
                    retries++
                    handler.removeCallbacks(retryPlayback)
                    handler.postDelayed(retryPlayback, 1_500L * retries)
                    return
                }
                spinner.visibility = View.GONE
                errorText.text = "This channel isn't working right now.\nPress ▲ / ▼ to try another one."
                errorText.visibility = View.VISIBLE
            }
        })

        player = p
        playerView.player = p
    }

    private fun mediaItemFor(url: String): MediaItem {
        val b = MediaItem.Builder().setUri(url)
        val path = url.lowercase().substringBefore('?')
        when {
            path.endsWith(".mpd") -> b.setMimeType(MimeTypes.APPLICATION_MPD)
            path.endsWith(".m3u8") || !path.substringAfterLast('/').contains('.') ->
                b.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        return b.build()
    }

    private fun play(c: Channel) {
        current = c
        retries = 0
        handler.removeCallbacks(retryPlayback)
        prefs.edit().putString(KEY_LAST, c.url).apply()
        adapter.setPlaying(c.url)
        errorText.visibility = View.GONE

        httpFactory.setUserAgent(c.userAgent ?: DEFAULT_UA)
        httpFactory.setDefaultRequestProperties(
            if (c.referrer != null) mapOf("Referer" to c.referrer) else emptyMap()
        )

        player?.apply {
            setMediaItem(mediaItemFor(c.url))
            prepare()
            playWhenReady = true
        }
        showBanner(c)
    }

    private fun zap(delta: Int) {
        if (visible.isEmpty()) return
        val i = visible.indexOfFirst { it.url == current?.url }
        val next = if (i < 0) 0 else (i + delta + visible.size) % visible.size
        play(visible[next])
    }

    private fun showBanner(c: Channel) {
        banner.text = "${c.name}\n${c.group}"
        banner.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, 4_000)
    }

    // -------------------------------------------------------------- channels

    private fun refresh(userInitiated: Boolean) {
        if (userInitiated) updateStatus("Updating channel list…")
        lifecycleScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { repo.download() }
                setChannels(list)
                if (userInitiated) Toast.makeText(this@MainActivity, "${list.size} channels loaded", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                if (all.isEmpty()) {
                    updateStatus("Couldn't load channels (${e.message}).\nCheck the network and press Refresh.")
                } else if (userInitiated) {
                    Toast.makeText(this@MainActivity, "Update failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun setChannels(list: List<Channel>) {
        all = list
        groups = withGroupCounts(list)
        updateStatus(null)
        applyFilter(scrollTop = true)
        maybeAutoStart()
    }

    private fun withGroupCounts(list: List<Channel>): List<Pair<String, Int>> =
        list.groupingBy { it.group }.eachCount().toList().sortedBy { it.first.lowercase() }

    private fun applyFilter(scrollTop: Boolean) {
        filterJob?.cancel()
        filterJob = lifecycleScope.launch {
            delay(120) // debounce typing
            val q = query.trim().lowercase()
            val g = group
            val src = all
            val favs = HashSet(favourites)
            val result = withContext(Dispatchers.Default) {
                src.filter { c ->
                    val groupOk = when (g) {
                        null -> true
                        FAVOURITES -> c.url in favs
                        else -> c.group == g
                    }
                    groupOk && (q.isEmpty() || c.nameLower.contains(q))
                }
            }
            visible = result
            adapter.submitList(result) { if (scrollTop) channelList.scrollToPosition(0) }
            updateStatus(if (result.isEmpty() && all.isNotEmpty()) "No channels found." else null)
        }
    }

    private fun maybeAutoStart() {
        if (autoStarted || player == null || all.isEmpty()) return
        val last = prefs.getString(KEY_LAST, null) ?: return
        val c = all.firstOrNull { it.url == last } ?: return
        autoStarted = true
        panel.visibility = View.GONE
        play(c)
    }

    private fun toggleFavourite(c: Channel) {
        val added = favourites.add(c.url)
        if (!added) favourites.remove(c.url)
        prefs.edit().putStringSet(KEY_FAVS, HashSet(favourites)).apply()
        Toast.makeText(this, if (added) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
        if (group == FAVOURITES) {
            applyFilter(scrollTop = false)
        } else {
            val i = adapter.currentList.indexOf(c)
            if (i >= 0) adapter.notifyItemChanged(i)
        }
    }

    private fun showGroupDialog() {
        val labels = buildList {
            add("All channels (${all.size})")
            add("★ Favourites (${favourites.size})")
            groups.forEach { add("${it.first} (${it.second})") }
        }
        AlertDialog.Builder(this)
            .setTitle("Category")
            .setItems(labels.toTypedArray()) { _, i ->
                group = when (i) {
                    0 -> null
                    1 -> FAVOURITES
                    else -> groups[i - 2].first
                }
                groupBtn.text = "Category: " + when (i) {
                    0 -> "All"
                    1 -> "★ Favourites"
                    else -> groups[i - 2].first
                }
                applyFilter(scrollTop = true)
            }
            .show()
    }

    private fun updateStatus(msg: String?) {
        if (msg == null) {
            status.visibility = View.GONE
        } else {
            status.text = msg
            status.visibility = View.VISIBLE
        }
    }

    // ------------------------------------------------------------------ panel

    private fun showPanel() {
        panel.animate().cancel()
        panel.alpha = 0f
        panel.visibility = View.VISIBLE
        panel.animate().alpha(1f).setDuration(120).start()
        focusList()
    }

    private fun hidePanel() {
        hideKeyboard()
        panel.animate().cancel()
        panel.animate().alpha(0f).setDuration(120).withEndAction { panel.visibility = View.GONE }.start()
    }

    private fun focusList() {
        channelList.post {
            if (visible.isEmpty()) {
                groupBtn.requestFocus()
                return@post
            }
            val idx = visible.indexOfFirst { it.url == current?.url }.coerceAtLeast(0)
            (channelList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, 200)
            channelList.post {
                (channelList.findViewHolderForAdapterPosition(idx)?.itemView ?: channelList).requestFocus()
            }
        }
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
    }

    // ------------------------------------------------------------------- keys

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val panelOpen = panel.visibility == View.VISIBLE
            when (e.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP -> { zap(-1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(1); return true }
                KeyEvent.KEYCODE_BACK -> if (panelOpen && current != null) {
                    hidePanel()
                    return true
                }
            }
            if (panelOpen) {
                // Shortcut: from anywhere in a long list, LEFT jumps straight to Search.
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_LEFT && channelList.hasFocus()) {
                    search.requestFocus()
                    return true
                }
                // From Search, DOWN goes back to the playing channel in the list.
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_DOWN && search.hasFocus()) {
                    hideKeyboard()
                    focusList()
                    return true
                }
            }
            if (!panelOpen) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { zap(-1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { zap(1); return true }
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER,
                    KeyEvent.KEYCODE_DPAD_LEFT,
                    KeyEvent.KEYCODE_MENU -> { showPanel(); return true }
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // -------------------------------------------------------------- lifecycle

    override fun onStart() {
        super.onStart()
        initPlayer()
        val c = current
        if (c != null) play(c) else maybeAutoStart()
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(retryPlayback)
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private companion object {
        const val KEY_FAVS = "favourites"
        const val KEY_LAST = "last_channel"
        const val FAVOURITES = "\u0000favourites"
        const val MAX_RETRIES = 2
        const val REFRESH_AFTER_MS = 12L * 60 * 60 * 1000
        const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 11; AndroidTV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    }
}
