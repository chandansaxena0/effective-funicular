package com.example.iptvtv

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Keeps a copy of the playlist on disk so the app opens instantly from cache
 * and refreshes the list in the background.
 */
class ChannelRepository(context: Context) {

    private val file = File(context.filesDir, "playlist.m3u")
    private val tmp = File(context.filesDir, "playlist.tmp")

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun cacheAgeMs(): Long =
        if (file.exists()) System.currentTimeMillis() - file.lastModified() else Long.MAX_VALUE

    /** Blocking – call from a background dispatcher. */
    fun loadCached(): List<Channel> {
        if (!file.exists()) return emptyList()
        return file.bufferedReader().use { M3uParser.parse(it) }
    }

    /** Blocking – call from a background dispatcher. */
    fun download(): List<Channel> {
        val request = Request.Builder().url(PLAYLIST_URL).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val body = response.body ?: throw IOException("Empty response")
            body.byteStream().use { input -> tmp.outputStream().use { input.copyTo(it) } }
        }
        val list = tmp.bufferedReader().use { M3uParser.parse(it) }
        if (list.isEmpty()) throw IOException("Playlist had no channels")
        tmp.copyTo(file, overwrite = true)
        tmp.delete()
        return list
    }

    companion object {
        const val PLAYLIST_URL = "https://iptv-org.github.io/iptv/index.m3u"
    }
}
