package com.example.iptvtv

data class Channel(
    val name: String,
    val url: String,
    val logo: String?,
    val group: String,
    val referrer: String? = null,
    val userAgent: String? = null,
) {
    /** Pre-lowercased once so searching 10k+ channels stays instant. */
    val nameLower: String = name.lowercase()
}
