package com.example.iptvtv

import java.io.BufferedReader

object M3uParser {

    fun parse(reader: BufferedReader): List<Channel> {
        val out = ArrayList<Channel>(12_000)
        var name: String? = null
        var logo: String? = null
        var group = "Undefined"
        var referrer: String? = null
        var userAgent: String? = null

        while (true) {
            val raw = reader.readLine() ?: break
            val line = raw.trim()
            if (line.isEmpty()) continue

            if (line.startsWith("#EXTINF")) {
                val lastQuote = line.lastIndexOf('"')
                val comma = line.indexOf(',', if (lastQuote > 0) lastQuote else 0)
                name = if (comma >= 0) line.substring(comma + 1).trim() else null
                logo = attr(line, "tvg-logo")
                group = attr(line, "group-title")?.substringBefore(';')?.trim()
                    ?.takeIf { it.isNotEmpty() } ?: "Undefined"
                referrer = null
                userAgent = null
            } else if (line.startsWith("#EXTVLCOPT:")) {
                val v = line.substringAfter('=', "")
                when {
                    line.startsWith("#EXTVLCOPT:http-referrer=") ||
                        line.startsWith("#EXTVLCOPT:http-referer=") -> referrer = v
                    line.startsWith("#EXTVLCOPT:http-user-agent=") -> userAgent = v
                }
            } else if (line[0] != '#') {
                val n = name
                if (n != null && n.isNotEmpty()) {
                    out.add(Channel(n, line, logo?.takeIf { it.isNotEmpty() }, group, referrer, userAgent))
                }
                name = null
                logo = null
                referrer = null
                userAgent = null
            }
        }
        return out
    }

    private fun attr(line: String, key: String): String? {
        val k = line.indexOf("$key=\"")
        if (k < 0) return null
        val start = k + key.length + 2
        val end = line.indexOf('"', start)
        return if (end > start) line.substring(start, end) else null
    }
}
