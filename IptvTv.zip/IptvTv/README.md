# IPTV Live – Android TV

Watches any channel from `https://iptv-org.github.io/iptv/index.m3u` (Kotlin, Media3/ExoPlayer, D-pad friendly).

## Build & install
1. Open this folder in **Android Studio** (Ladybug or newer). It will sync Gradle and create the wrapper.
2. Run on an Android TV emulator or a TV/Fire TV/box with USB or network debugging (`adb connect <tv-ip>:5555`).
3. Or build an APK: `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`, then `adb install -r app-release.apk`.

## Remote controls
| Key | Action |
|---|---|
| OK / ← / Menu (video playing) | Open channel list |
| ▲ / ▼ (video playing) or CH+ / CH- | Previous / next channel (within the current category/search) |
| OK on a list item | Play |
| Hold OK on a list item | Add / remove favourite ★ |
| Back | Hide the list (press again to exit) |

## Why it stays smooth
- Playlist (~10k channels) is cached on disk; app opens from cache and refreshes in the background every 12 h (or via **Refresh**).
- Parsing, filtering and searching run off the main thread; search is debounced.
- RecyclerView with DiffUtil, fixed-size items, no item animations, tiny cached logos (Coil).
- ExoPlayer tuned for fast channel start (small start buffer), `SurfaceView` rendering, HLS/DASH auto-detect, decoder fallback, automatic retry, and last frame kept while zapping.
- Supports the `#EXTVLCOPT` Referer / User-Agent headers some iptv-org streams need.

Note: iptv-org lists thousands of free public streams; some are offline or geo-blocked at any given time – just zap to the next one.
